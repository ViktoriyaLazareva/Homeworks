#include <iostream>
#include <windows.h>
#include <string>
#include <fstream>

using namespace std;

int main()
//Task 1----------------------------------------------
{//create 1-th file
    ofstream to_file_1("test_1.txt");

    if(!to_file_1){
        cout << "Failed to create out file!\n";
    }else
    cout << "File 1 created successfully!\n";
//write to 1-th file:
    for(int i=0; i<5; i++){
        to_file_1 << "Hello World!" <<" ";
    }
    to_file_1.close();

//create 2th file
    ofstream to_file_2("test_2.txt");

    if(!to_file_2){
        cout << "Failed to create out file!\n";
    }else
    cout << "File 2 created successfully!\n";
//write to 2th file:
    for(int i=0; i<5; i++){
        to_file_2 << "Bye-bye World!" <<" ";
    }
    //to_file_2 << "\n";
    to_file_2.close();
//----------------------------------------------------
//Task2:----------------------------------------------
//read 1-th file:
    ifstream from_file_1 ("test_1.txt");
    string temp_string;

    if(!from_file_1){
        cout << "Failed to opened file 1!\n";
    }

    cout << "\n" << "Read and buffering 1-th file:" << "\n";

    getline(from_file_1, temp_string);
    string* buffer_1 = new string;
    if(buffer_1 == nullptr){
        cout << "Error buffering!";
    }
    (*buffer_1) = temp_string;

    from_file_1.close();
    cout << (*buffer_1) << " " <<"\n";

//read 2-th file:
    ifstream from_file_2 ("test_2.txt");

    if(!from_file_2){
        cout << "Failed to opened file 2!\n";
    }

    cout << "\n" << "Read and buffering 2th file:" << "\n";

    getline(from_file_2, temp_string);
    string* buffer_2 = new string;
    if(buffer_2 == nullptr){
        cout << "Error buffering!";
    }
    (*buffer_2) = temp_string;

    from_file_2.close();
    cout << (*buffer_2)<< " " << "\n" <<"\n";

//create 3-th file
    ofstream to_file_3 ("test_3.txt");//test_3 = test_1+test_2.

    if(!to_file_3){
        cout << "Failed to create out file!\n";
    }else
    cout << "File 3 created successfully!\n";

//write to 3-th file:
    to_file_3 << (*buffer_1) << "\n" << (*buffer_2);

    delete buffer_1;
    delete buffer_2;
    to_file_3.close();

//read 3-th file:
    ifstream from_file_3 ("test_3.txt");

    if(!from_file_3){
        cout << "\n" << "Failed to opened file 3!\n";
    }

    cout << "Read file 3:" << "\n";
    while(!from_file_3.eof()){
        getline(from_file_3, temp_string);
        cout << temp_string << "\n";
    }
    cout << endl;
//------------------------------------------------------

    system("Pause");
    return 0;
}
