#include <iostream>
#include <windows.h>
#include <fstream>

//Request parameters to search through the arguments of the main function
//Correct request: C:\Users\lavde\Documents\CobeBlocks Projects\MainArgs\bin\Debug>MainArgs.exe test.txt Hello

using namespace std;

int main(int argc, char** argv)
{
    string adress;
    string word;
    string temp;

    adress = argv[1];
    word = argv[2];

    ifstream from_file(adress);
    if(from_file){
        cout << "file opened" <<"\n";

        while(!from_file.eof()){
        from_file >> temp;
        if(temp == word){
        cout << word <<" " <<"found!" <<"\n";
        break;
        }
        if(from_file.eof()){
        cout << word <<" "<<"not found" <<"\n";
        }
        }
    }
    else{
        cout <<"file not exist"<<"\n";
    }

    system("Pause");
    return 0;
}
