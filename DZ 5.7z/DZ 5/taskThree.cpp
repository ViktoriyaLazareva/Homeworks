#include <iostream>
using namespace std;

bool taskThree(int *data3) {
    int sum1 = 0;//summa total

    for(int i = 0; i < 5; i++) {
    sum1 = sum1 + data3[i];
    }
        if(sum1 % 2 != 0) {
        return false;
        }
        else {
        return true;
        }
}
