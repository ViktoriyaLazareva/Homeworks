#ifndef TASKFOUR_SHIFTRIGHT_H_INCLUDED
#define TASKFOUR_SHIFTRIGHT_H_INCLUDED

void taskFour_ShiftRight(int *data4, int a);

#endif // TASKFOUR_SHIFTRIGHT_H_INCLUDED
