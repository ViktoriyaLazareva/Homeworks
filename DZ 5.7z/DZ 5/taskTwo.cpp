#include <iostream>
using namespace std;

void taskTwo(int *data2) {
    for(int i = 0; i < 8; i++) {
    data2[0] = 1;
    data2[i + 1] = data2[i] + 3;
    cout << data2[i] << " ";
    }
}
