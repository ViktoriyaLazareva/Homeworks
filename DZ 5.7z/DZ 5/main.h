#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED
#include <iostream>
#include "taskOne.h"
#include "taskTwo.h"
#include "taskThree.h"
#include "taskFour_ShiftLeft.h"
#include "taskFour_ShiftRight.h"


#endif // MAIN_H_INCLUDED
