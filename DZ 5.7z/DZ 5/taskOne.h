#ifndef TASKONE_H_INCLUDED
#define TASKONE_H_INCLUDED

void taskOne(int *data1);

#endif // TASKONE_H_INCLUDED
