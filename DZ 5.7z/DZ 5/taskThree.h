#ifndef TASKTHREE_H_INCLUDED
#define TASKTHREE_H_INCLUDED

bool taskThree(int *data3);

#endif // TASKTHREE_H_INCLUDED
