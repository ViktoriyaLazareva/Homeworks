#ifndef TASKTWO_H_INCLUDED
#define TASKTWO_H_INCLUDED

void taskTwo(int *data2);


#endif // TASKTWO_H_INCLUDED
