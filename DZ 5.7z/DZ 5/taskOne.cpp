#include <iostream>
using namespace std;

void taskOne(int *data1) {

  for(int i = 0; i < 10; i++) {
    data1[i] = data1[i] ^ 1;
    cout << data1[i] << " ";

    }
}
