#include <iostream>
using namespace std;

void taskFour_ShiftRight(int *data4, int a)  {
int temp = 0;

    for(int i = 0; i < 5; i++) {
     cout << data4[i] << " ";//output original massive
     }
     cout << "\n";

    for(int ii = 0; ii < a; ii++) {
    temp = data4[4];

        for(int i = 5; i > 0; i--){
        data4[i] = data4[i - 1];
        }
        data4[0] = temp;
   }

    for(int i = 0; i < 5; i++) {
    cout << data4[i] << " ";
    }
}
