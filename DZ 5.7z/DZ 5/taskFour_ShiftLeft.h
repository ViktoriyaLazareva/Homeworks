#ifndef TASKFOUR_SHIFTLEFT_H_INCLUDED
#define TASKFOUR_SHIFTLEFT_H_INCLUDED

void taskFour_ShiftLeft(int *data4, int a);

#endif // TASKFOUR_SHIFTLEFT_H_INCLUDED
